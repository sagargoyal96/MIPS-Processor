#! /bin/bash


TEST_DIR="traces"
OUT_DIR="outputs"
MY_OUT_DIR="my_outputs"
EXEC="code/sim"
rm -rf $MY_OUT_DIR
mkdir -p $MY_OUT_DIR

###########################################################################

code/sim -bs 64 -is 8192 -ds 8192 -a 4 -wt -nw traces/spice.trace > $MY_OUT_DIR/spice.csv
code/sim -bs 64 -is 8192 -ds 8192 -a 4 -wt -nw traces/tex.trace > $MY_OUT_DIR/tex.csv
code/sim -bs 64 -is 8192 -ds 8192 -a 4 -wt -nw traces/cc.trace > $MY_OUT_DIR/cc.csv